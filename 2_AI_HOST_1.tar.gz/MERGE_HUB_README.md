# Merge Hub — объединение контейнеров из разных диалогов

Скрипт: merge_hub.py (этот же файл можно скопировать в любой другой контейнер)

## Как пользоваться
1. В КАЖДОМ другом контейнере (источнике) запусти:
   python3 merge_hub.py serve --port 8777
   и подними для него cloudflare-tunnel: cloudflared tunnel --url http://localhost:8777
   → получишь ссылку вида https://что-то.trycloudflare.com — это URL источника.

2. Здесь (главный контейнер) уже запущен master на :8899, интерфейс:
   https://epa-chronicle-beta-mlb.trycloudflare.com

3. В интерфейсе: добавь источник (имя + его URL) → «Сканировать» →
   «Забрать НОВЫЕ файлы» (и при желании «Переписать изменённые»).
   Всё сложится в /workspace/merged/<имя_источника>/...

4. Есть и CLI без браузера:
   python3 merge_hub.py cli --add dialog2 https://xxx.trycloudflare.com
   python3 merge_hub.py cli --scan dialog2
   python3 merge_hub.py cli --pull dialog2

Конфликты имён не перезаписываются молча: при overwrite старый файл
сохраняется как <имя>.conflict_<метка>.
