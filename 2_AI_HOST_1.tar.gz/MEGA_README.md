
## Статус TinkCloud (проверено 26.10.2026)
- rclone + fuse3 установлены, профиль [tinkcloud] создан (url=https://tinkcloud.com/dav).
- Сервер жив: OPTIONS /dav отдаёт 200 и DAV: 1,2. НО ЛЮБЫЕ PROPFIND/PUT/MKCOL возвращают 401 "Authentication required" — токен tck_... не принимается ни как Basic-пароль (с юзером и без), ни как Bearer. webdav.tinkcloud.com — не существует в DNS.
- Вывод: учётка/токен не активируют WebDAV на стороне TinkCloud. Нужна свежая проверка в панели TinkCloud (токен мог быть отозван/не активирован для WebDAV).
- Локальный каркас Mega-Workspace готов: /workspace/mega/manifest/manifest.json, /workspace/register.sh, /workspace/mega_status.sh (диагностика). После получения валидного токена: bash mega_setup.sh && TINK_TOKEN=... rclone config update ... && bash register.sh — всё остальное уже настроено.
