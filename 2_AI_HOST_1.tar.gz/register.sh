#!/bin/bash
# Mega-Workspace: регистрация контейнера в манифесте TinkCloud
CONT_ID="${MEGA_CONTAINER_ID:-$(hostname)}"
LOCAL_DIR="/workspace"
SIZE_KB=$(du -sk "$LOCAL_DIR" 2>/dev/null | cut -f1)
mkdir -p /mnt/tinkcloud
if ! mountpoint -q /mnt/tinkcloud; then
  fusermount3 -u /mnt/tinkcloud 2>/dev/null
  rclone mount tinkcloud:Mega-Workspace /mnt/tinkcloud --vfs-cache-mode writes --daemon || exit 1
fi
M="/mnt/tinkcloud/manifest"
mkdir -p "$M/nodes" "$M/logs"
cat > "$M/nodes/$CONT_ID.json" <<JSON
{"id":"$CONT_ID","registered_at":"$(date -Is)","local_dir":"$LOCAL_DIR","size_kb":$SIZE_KB,"quota_gb":9.5}
JSON
echo "$(date -Is) $CONT_ID size_kb=$SIZE_KB" >> "$M/logs/registry.log"
fusermount3 -u /mnt/tinkcloud 2>/dev/null
echo "registered: $CONT_ID"
