import os, cgi
from http.server import BaseHTTPRequestHandler

SAVE = "/workspace/incoming"

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        page = """<html><body style="font-family:sans-serif;padding:30px">
        <h2>&#128230; Upload</h2>
        <form method="POST" enctype="multipart/form-data">
        <input type="file" name="f"><br><br>
        <button type="submit" style="padding:8px 16px">Upload</button>
        </form></body></html>"""
        self.wfile.write(page.encode())

    def do_POST(self):
        form = cgi.FieldStorage(fp=self.rfile, headers=self.headers,
                                environ={"REQUEST_METHOD": "POST"})
        item = form["f"]
        name = os.path.basename(item.filename or "upload.bin")
        path = os.path.join(SAVE, name)
        with open(path, "wb") as out:
            while True:
                chunk = item.file.read(1024 * 1024)
                if not chunk: break
                out.write(chunk)
        size = os.path.getsize(path)
        self.send_response(200)
        self.end_headers()
        self.wfile.write(f"OK saved {name} ({size} bytes)".encode())
        print(f"[saved] {path} ({size} bytes)", flush=True)

    def log_message(self, *a): pass

print("listening on :8787", flush=True)
from http.server import HTTPServer
HTTPServer(("127.0.0.1", 8787), H).serve_forever()
