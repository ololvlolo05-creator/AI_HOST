#!/usr/bin/env python3
import os, base64, shutil
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = "/workspace"
USER, PASS = "root", "FilesPass2026"

class H(BaseHTTPRequestHandler):
    def auth_ok(self):
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            u, p = base64.b64decode(h[6:]).decode().split(":", 1)
            return u == USER and p == PASS
        return False

    def require_auth(self):
        if not self.auth_ok():
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="workspace"')
            self.end_headers()
            return False
        return True

    def path_to_fs(self):
        p = self.path.split("?")[0].strip("/")
        return os.path.normpath(os.path.join(ROOT, p)) if p else ROOT

    def do_PROPFIND(self):
        if not self.require_auth(): return
        fs = self.path_to_fs()
        depth = self.headers.get("Depth", "1")
        if not os.path.exists(fs):
            self.send_response(404); self.end_headers(); return
        items = []
        def add(name, full):
            st = os.stat(full)
            isdir = os.path.isdir(full)
            href = "/" + name.strip("/") if name != "/" else "/"
            items.append((href, isdir, st.st_size, st.st_mtime))
        if os.path.isdir(fs):
            rel = os.path.relpath(fs, ROOT).replace("\\", "/")
            base = "/" if rel == "." else "/" + rel + "/"
            add(base.rstrip("/"), fs) if False else None
            hrefs = ["/"] if rel == "." else ["", ]
            xml = '<?xml version="1.0"?>\n<d:multistatus xmlns:d="DAV:">'
            def mk(href, isdir, size, mtime):
                from email.utils import formatdate
                ct = "httpd/unix-directory" if isdir else "application/octet-stream"
                res = "<d:response><d:href>%s</d:href><d:propstat><d:prop>" % href
                res += '<d:resourcetype><d:collection/></d:resourcetype>' if isdir else '<d:resourcetype/>'
                res += '<d:getcontenttype>%s</d:getcontenttype>' % ct
                res += '<d:getcontentlength>%d</d:getcontentlength>' % (0 if isdir else size)
                res += '<d:getlastmodified>%s</d:getlastmodified>' % formatdate(mtime, usegmt=True)
                res += '</d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>'
                return res
            root_href = "/" if rel == "." else "/" + rel + "/"
            xml += mk(root_href, True, 0, os.stat(fs).st_mtime)
            if depth != "0":
                for e in sorted(os.listdir(fs)):
                    full = os.path.join(fs, e)
                    st = os.stat(full)
                    href = ("" if rel == "." else "/" + rel + "/") + e
                    xml += mk(href, os.path.isdir(full), st.st_size, st.st_mtime)
            xml += "</d:multistatus>"
            b = xml.encode()
            self.send_response(207)
            self.send_header("Content-Type", "application/xml; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)
        else:
            from email.utils import formatdate
            st = os.stat(fs)
            xml = ('<?xml version="1.0"?><d:multistatus xmlns:d="DAV:"><d:response><d:href>/%s</d:href>'
                   '<d:propstat><d:prop><d:resourcetype/><d:getcontentlength>%d</d:getcontentlength>'
                   '<d:getlastmodified>%s</d:getlastmodified></d:prop>'
                   '<d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response></d:multistatus>') % (rel, st.st_size, formatdate(st.st_mtime, usegmt=True))
            b = xml.encode()
            self.send_response(207)
            self.send_header("Content-Type", "application/xml")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

    def do_GET(self):
        if not self.require_auth(): return
        fs = self.path_to_fs()
        if os.path.isfile(fs):
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(os.path.getsize(fs)))
            self.end_headers()
            with open(fs, "rb") as f: shutil.copyfileobj(f, self.wfile)
        else:
            self.send_response(404); self.end_headers()

    def do_PUT(self):
        if not self.require_auth(): return
        fs = self.path_to_fs()
        n = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(n)
        os.makedirs(os.path.dirname(fs), exist_ok=True)
        with open(fs, "wb") as f: f.write(data)
        self.send_response(201 if n else 204)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_MKCOL(self):
        if not self.require_auth(): return
        fs = self.path_to_fs()
        try:
            os.makedirs(fs); self.send_response(201)
        except FileExistsError:
            self.send_response(405)
        self.end_headers()

    def do_DELETE(self):
        if not self.require_auth(): return
        fs = self.path_to_fs()
        if os.path.isdir(fs): shutil.rmtree(fs, ignore_errors=True)
        elif os.path.isfile(fs): os.remove(fs)
        self.send_response(204); self.end_headers()

    def do_MOVE(self):
        if not self.require_auth(): return
        dest = self.headers.get("Destination", "")
        d = dest.replace("/", "").lstrip("/")
        if d.startswith("localhost"): d = d[d.find("localhost")+9:]
        dfs = os.path.normpath(os.path.join(ROOT, d.split("?")[0]))
        fs = self.path_to_fs()
        if os.path.exists(fs):
            os.makedirs(os.path.dirname(dfs), exist_ok=True)
            shutil.move(fs, dfs)
            self.send_response(201)
        else:
            self.send_response(404)
        self.end_headers()

    def do_COPY(self):
        if not self.require_auth(): return
        dest = self.headers.get("Destination", "").split("?")[0]
        d = dest.lstrip("/")
        dfs = os.path.normpath(os.path.join(ROOT, d))
        fs = self.path_to_fs()
        if os.path.exists(fs):
            shutil.copytree(fs, dfs) if os.path.isdir(fs) else shutil.copy(fs, dfs)
            self.send_response(201)
        else:
            self.send_response(404)
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("DAV", "1,2")
        self.send_header("Allow", "OPTIONS,GET,PUT,PROPFIND,MKCOL,DELETE,MOVE,COPY")
        self.send_header("MS-Author-Via", "DAV")
        self.end_headers()

    def do_HEAD(self):
        if not self.require_auth(): return
        fs = self.path_to_fs()
        self.send_response(200 if os.path.exists(fs) else 404)
        if os.path.isfile(fs): self.send_header("Content-Length", str(os.path.getsize(fs)))
        self.end_headers()

    def log_message(self, *a): pass

ThreadingHTTPServer(("127.0.0.1", 8888), H).serve_forever()
