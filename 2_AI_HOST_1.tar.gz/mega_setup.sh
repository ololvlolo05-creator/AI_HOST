#!/bin/bash
# Mega-Workspace: подготовка контейнера (rclone + WebDAV tinkcloud)
set -e
command -v rclone >/dev/null || { apt-get update -qq; DEBIAN_FRONTEND=noninteractive apt-get install -y rclone fuse3 curl; }
[ -f ~/.config/rclone/rclone.conf ] && grep -q '\[tinkcloud\]' ~/.config/rclone/rclone.conf || \
  rclone config create tinkcloud webdav url=https://tinkcloud.com/dav vendor=Other user="ololl08@tinkmail.me" pass=$(rclone obscure "${TINK_TOKEN:?}") >/dev/null
mkdir -p /mnt/tinkcloud
echo "готово. проверка: rclone lsd tinkcloud:"
