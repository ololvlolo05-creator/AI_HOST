#!/bin/bash
# Автовосстановление: SSH + cloudflared-туннели (SSH/SFTP и HTTP для скачивания exe)
export PATH=$PATH:/usr/local/bin
echo "root:FilesPass2026" | chpasswd 2>/dev/null
mkdir -p /run/sshd
pgrep -x sshd >/dev/null || /usr/sbin/sshd -D >>/tmp/sshd.log 2>&1 &
if ! pgrep -f "tunnel --url ssh://localhost:22" >/dev/null; then
  nohup /usr/local/bin/cloudflared tunnel --url ssh://localhost:22 --no-autoupdate >/tmp/cf_ssh.log 2>&1 &
fi
if ! pgrep -f "tunnel --url http://localhost:8888" >/dev/null; then
  cd /workspace && nohup python3 webdav_server.py >/tmp/webdav.log 2>&1 &
  nohup /usr/local/bin/cloudflared tunnel --url http://localhost:8888 --no-autoupdate >/tmp/cf_dav.log 2>&1 &
fi
# Chunked upload server (port 8788) — приём больших архивов через curl -T
if ! curl -s -o /dev/null http://127.0.0.1:8788/; then
  nohup python3 /workspace/upload_chunk.py >/tmp/upload_chunk.log 2>&1 &
  nohup /usr/local/bin/cloudflared tunnel --url http://localhost:8788 --no-autoupdate >/tmp/cf_upl.log 2>&1 &
  sleep 1
fi
sleep 12
{ echo "SSH_TUNNEL: $(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' /tmp/cf_ssh.log | head -1)"
  echo "HTTP_TUNNEL: $(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' /tmp/cf_dav.log | head -1)"
  echo "UPLOAD_TUNNEL: $(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' /tmp/cf_upl.log | head -1)"; } > /tmp/tunnel_urls.txt
cat /tmp/tunnel_urls.txt
# конфиг sshd для root/пароль-входа (пересоздаётся при каждом запуске)
mkdir -p /etc/ssh/sshd_config.d; printf "PermitRootLogin yes\nPasswordAuthentication yes\nUsePAM no\nKbdInteractiveAuthentication no\n" > /etc/ssh/sshd_config.d/99-root.conf 2>/dev/null || true

# --- обменник mailbox (:8790) + туннель сайта ---
pgrep -f "mailbox.py" >/dev/null || (nohup python3 /workspace/mailbox.py >> /tmp/mail.log 2>&1 &)
if ! pgrep -f "url http://localhost:8790" >/dev/null; then
  nohup cloudflared tunnel --no-autoupdate --url http://localhost:8790 > /tmp/cf_mail.log 2>&1 &
fi
grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' /tmp/cf_mail.log | head -1 > /tmp/mail_url.txt

# --- MESH + MEGADISK: единый диск поверх всех контейнеров ---
cd /workspace/cluster
BOOT=$(python3 -c "import json;d=json.load(open('peers.json'));print(max(d.values(),key=lambda v:v.get('last_seen',0)).get('url',''))" 2>/dev/null)
if ! pgrep -f "megadisk.py" >/dev/null; then
  [ -n "$BOOT" ] && export MESH_BOOTSTRAP="$BOOT"
  MESH_NAME=gateway nohup python3 megadisk.py --port 8443 >> /tmp/megadisk.log 2>&1 &
fi
if ! pgrep -f "tunnel --url http://localhost:8443" >/dev/null; then
  nohup cloudflared tunnel --no-autoupdate --url http://localhost:8443 > /tmp/cf_disk.log 2>&1 &
fi
sleep 6
DISK_URL=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' /tmp/cf_disk.log | head -1)
echo "$DISK_URL" > /tmp/mesh_url.txt
#告诉 mesh-агенту его публичный url и он сам разшлёт hello всем соседям из памяти
if ! pgrep -f "mesh.py" >/dev/null; then
  MESH_NAME=w1 MESH_URL="https://$DISK_URL" nohup python3 /workspace/cluster/mesh.py >> /tmp/mesh.log 2>&1 &
else
  curl -s -X POST http://127.0.0.1:8585/hello -d "{\"name\":\"w1\",\"url\":\"https://$DISK_URL\"}" -H 'Content-Type: application/json' >/dev/null
fi
{ echo "MEGADISK_TUNNEL: https://$DISK_URL"; cat /tmp/tunnel_urls.txt; } > /tmp/tunnel_urls_new.txt && mv /tmp/tunnel_urls_new.txt /tmp/tunnel_urls.txt
