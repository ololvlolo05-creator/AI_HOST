#!/usr/bin/env python3
"""Файловый обменник «почта» + зашифрованный приём архивов.

Как устроено (без аккаунтов и передачи данных между людьми):
  /workspace/mail/<ящик>/inbox/   — сюда кладут файлы (через сайт или SFTP-диск)
  /workspace/mail/<ящик>/outbox/  — ИИ читает inbox, пишет ответ в outbox
Читатель открывает свой ящик на сайте: видит входящие и ответы.

Шифрование больших файлов (обход 100 МБ лимита Cloudflare + защита кода):
  PUT /enc?name=x&total=N&part=i   — часть файла (<=95 МБ), AES-GAD с эфемерным ключом
  PUT /key                          — {id, alg:"x25519", wrapped_key(b64)} — ключ, зашитый X25519
  GET /dec?name=x                   — сервер расшифровывает (своим приватным ключом) и отдаёт RAR
Приватный ключ сервера: /workspace/.vault_key (не покидает контейнер).
"""
import os, re, json, base64, hashlib, urllib.parse, secrets
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = "/workspace"
MAIL = os.path.join(ROOT, "mail")
INCOMING = os.path.join(ROOT, "incoming")
CHUNKS = os.path.join(ROOT, "chunks")
ENC = os.path.join(ROOT, "enc")
KEYFILE = os.path.join(ROOT, ".vault_key")
PUBKEY_FILE = os.path.join(ROOT, "pubkey.txt")
BOX_RE = re.compile(r"^[A-Za-z0-9_.\-]{1,64}$")
NAME_RE = re.compile(r"^[A-Za-z0-9._\- ]{1,128}$")

os.makedirs(MAIL, exist_ok=True); os.makedirs(ENC, exist_ok=True)

def safe_join(base, *parts):
    p = os.path.abspath(os.path.join(base, *[os.path.basename(x) for x in parts]))
    if not base or not p.startswith(os.path.abspath(base)): return None
    return p

def box_dir(box, sub):
    if not box or not BOX_RE.match(box): return None
    d = os.path.join(MAIL, box, sub)
    os.makedirs(d, exist_ok=True)
    return d

# ---------- HTML ----------
PAGE = """<!doctype html><html lang="ru"><head><meta charset="utf-8">
<title>Почтовый обменник</title><style>
body{font-family:Segoe UI,sans-serif;max-width:760px;margin:30px auto;padding:0 16px;background:#fafafa}
.card{background:#fff;border:1px solid #ddd;border-radius:10px;padding:16px;margin:14px 0}
h2{margin-top:0} input,button{font-size:15px;padding:7px} button{cursor:pointer}
table{border-collapse:collapse;width:100%} td,th{padding:6px 8px;border-bottom:1px solid #eee;text-align:left}
#log{white-space:pre-wrap;background:#111;color:#0f0;padding:10px;border-radius:6px;font-family:monospace;font-size:13px;min-height:50px}
.bar{height:20px;background:#eee;border-radius:5px;overflow:hidden;margin:8px 0}.fill{height:100%;width:0;background:#2b7;transition:width .2s}
a{color:#06c}</style></head><body>
<h2>&#9993; Файловый обменник «почта»</h2>

<div class="card"><h3>1. Открыть свой ящик</h3>
<input id="box" placeholder="имя ящика (придумай сам)"> <button onclick="openBox()">Открыть</button>
<div id="list"></div></div>

<div class="card"><h3>2. Отправить файл в чей-то ящик</h3>
Ящик получателя: <input id="to" placeholder="например vanya"><br><br>
Маленький файл (&lt;95 МБ): <input type="file" id="sf"> <button onclick="sendSmall()">Отправить</button><br><br>
Большой архив (RAR/ZIP, до ГБ) — шифруется прямо в браузере: <input type="file" id="bf"> <button onclick="sendBig()">Отправить шифром</button>
<div class="bar"><div class="fill" id="fill"></div></div><div id="log"></div></div>

<div class="card"><h3>3. Расшифровать полученный архив</h3>
Открой свой ящик, скачай письмо .key.txt и вставь его текст сюда:<br>
<textarea id="keymsg" style="width:100%;height:90px;font-family:monospace"></textarea><br>
<button onclick="decrypt()">Расшифровать и скачать</button> <span id="dst"></span></div>

<script>
const CS = 90*1024*1024;
const log=document.getElementById('log'), fill=document.getElementById('fill');
function L(m){log.textContent+=m+"\n";log.scrollTop=1e9;}
function b64(buf){const u=new Uint8Array(buf);let s='';for(let i=0;i<u.length;i++)s+=String.fromCharCode(u[i]);return btoa(s);}
function unb64(str){const s=atob(str);const u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u;}

async function openBox(){
  const b=document.getElementById('box').value.trim(); if(!b){alert("Введи имя ящика");return;}
  const r=await fetch(`/api/list?box=${encodeURIComponent(b)}`); const j=await r.json();
  let h="<table><tr><th>Входящие</th><th>Размер</th><th></th></tr>";
  (j.inbox||[]).forEach(f=>{h+=`<tr><td>${f.name}</td><td>${f.size}</td><td><a href="/api/get?box=${encodeURIComponent(b)}&dir=inbox&f=${encodeURIComponent(f.name)}">скачать</a></td></tr>`;});
  h+="</table><table><tr><th>Ответы ИИ</th><th>Размер</th><th></th></tr>";
  (j.outbox||[]).forEach(f=>{h+=`<tr><td>${f.name}</td><td>${f.size}</td><td><a href="/api/get?box=${encodeURIComponent(b)}&dir=outbox&f=${encodeURIComponent(f.name)}">скачать</a></td></tr>`;});
  h+="</table>"; document.getElementById('list').innerHTML=h;
}

async function sendSmall(){
  const f=document.getElementById('sf').files[0], to=document.getElementById('to').value.trim();
  if(!f||!to){alert("Выбери файл и укажи ящик");return;}
  if(f.size>95*1024*1024){L("Файл больше 95 МБ — жми «Отправить шифром»");return;}
  const fd=new FormData(); fd.append('box',to); fd.append('f',f);
  const r=await fetch('/api/send',{method:'POST',body:fd}); L(await r.text());
}

// Гибрид: ECDSA-P256 ключ сервера + эфемерный ECDH-P256 -> HKDF -> AES-GCM для упаковки случайного AES-ключа файла.
async function getServerKey(){
  const r=await fetch('/api/pubkey'); const raw=unb64((await r.text()).trim());
  return await crypto.subtle.importKey('raw',raw,{name:'X25519'},false,[]);
}
async function deriveShared(ephPriv, serverPub){
  const raw=await crypto.subtle.deriveBits({name:'X25519',public:serverPub},ephPriv,32*8);
  const hk=await crypto.subtle.importKey('raw',raw,'HKDF',false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'HKDF',salt:new TextEncoder().encode('mailbox-v1'),info:new TextEncoder().encode('wrap-aes'),hash:'SHA-256'},hk,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}

async function sendBig(){
  const f=document.getElementById('bf').files[0], to=document.getElementById('to').value.trim();
  if(!f||!to){alert("Выбери файл и укажи ящик");return;}
  const name=f.name.replace(/[^A-Za-z0-9._-]/g,'_');
  const serverPub=await getServerKey();
  const eph=await crypto.subtle.generateKey({name:'X25519'},true,['deriveBits','deriveKey']);
  const wrapK=await deriveShared(eph.privateKey,serverPub);
  const fileKey=await crypto.subtle.generateKey({name:'AES-GCM',length:256},true,['encrypt']);
  const keyRaw=await crypto.subtle.exportKey('raw',fileKey);
  const wiv=crypto.getRandomValues(new Uint8Array(12));
  const wrapped=await crypto.subtle.encrypt({name:'AES-GCM',iv:wiv},wrapK,keyRaw);
  const pubRaw=await crypto.subtle.exportKey('raw',eph.publicKey);
  const keyid=Math.random().toString(36).slice(2,10)+Date.now().toString(36);
  const total=Math.ceil(f.size/CS);
  L(`Шифрую ${f.name} (${(f.size/1048576).toFixed(1)} MB), частей: ${total}`);
  for(let i=0;i<total;i++){
    const buf=await f.slice(i*CS,(i+1)*CS).arrayBuffer();
    const civ=crypto.getRandomValues(new Uint8Array(12));
    const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv:civ},fileKey,buf);
    const body=new Uint8Array(12+ct.byteLength); body.set(civ,0); body.set(new Uint8Array(ct),12);
    let ok=false;
    for(let r=0;r<3&&!ok;r++){try{
      const res=await fetch(`/enc?name=${encodeURIComponent(keyid+'_'+name)}&total=${total}&part=${i}`,{method:'PUT',body:body});
      if(res.ok){ok=true;L(`часть ${i+1}/${total}: ок`);}else L(`часть ${i+1}: HTTP ${res.status}, повтор ${r+1}`);
    }catch(e){L(`часть ${i+1}: сбой сети, повтор ${r+1}`);}}
    if(!ok){L("ОСТАНОВЛЕНО — попробуй ещё раз");document.getElementById('go')&&0;return;}
    fill.style.width=Math.round((i+1)/total*100)+"%";fill.textContent=Math.round((i+1)/total*100)+"%";
  }
  const msg=["MAILBOX-ENCRYPTED-V1",`id=${keyid}`,`file=${name}`,`size=${f.size}`,`parts=${total}`,
    "alg=X25519-HKDF-AESGCM",`ephemeral_pub=${b64(pubRaw)}`,`wrapped_key=${b64(wrapped)}`,`wrap_iv=${b64(wiv)}`].join("\n");
  const rr=await fetch(`/api/keymsg?box=${encodeURIComponent(to)}&name=${encodeURIComponent(name+'.key.txt')}`,{method:'PUT',body:msg});
  L("Письмо-ключ -> ящик "+to+": "+(await rr.text()));
  L("ВСЁ. Получатель открывает ящик, копирует текст .key.txt в блок 3 и скачивает архив.");
}

async function decrypt(){
  const txt=document.getElementById('keymsg').value;
  const r=await fetch('/dec',{method:'POST',body:txt});
  if(!r.ok){L("Ошибка: "+(await r.text()));return;}
  const blob=await r.blob(); const a=document.createElement('a');
  a.href=URL.createObjectURL(blob); a.download=(txt.match(/file=(.+)/)||[])[1]||'decrypted.bin';
  document.body.appendChild(a); a.click(); a.remove();
  document.getElementById('dst').textContent="Скачано ✔ ("+(blob.size/1048576).toFixed(1)+" MB)";
}
</script></body></html>"""

from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives import serialization

def _server_keys():
    pemf = os.path.join(ROOT, ".vault_key")
    if os.path.exists(pemf):
        try:
            priv = serialization.load_pem_private_key(open(pemf,"rb").read(), None)
            if not isinstance(priv, X25519PrivateKey): raise TypeError
        except Exception:
            priv = X25519PrivateKey.generate()
    else:
        priv = X25519PrivateKey.generate()
    open(pemf,"wb").write(priv.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    pub_raw = priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return priv, pub_raw

SRV_PRIV, SRV_PUB_RAW = _server_keys()

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

def unwrap_file_key(eph_pub_b64, wrapped_b64, iv_b64):
    eph_pub = X25519PublicKey.from_public_bytes(base64.b64decode(eph_pub_b64))
    shared = SRV_PRIV.exchange(eph_pub)
    aek = HKDF(algorithm=hashes.SHA256(), length=32, salt=b"mailbox-v1", info=b"wrap-aes").derive(shared)
    return AESGCM(aek).decrypt(base64.b64decode(iv_b64), base64.b64decode(wrapped_b64), None)

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")

    def do_OPTIONS(self):
        self.send_response(200); self._cors()
        self.send_header("Content-Length", "0"); self.end_headers()

    def _send(self, code, body=b"", ctype="text/plain; charset=utf-8"):
        if isinstance(body, str): body = body.encode()
        self.send_response(code); self._cors()
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if body: self.wfile.write(body)

    def _read_body(self):
        te = (self.headers.get("Transfer-Encoding") or "").lower()
        if "chunked" in te:
            buf = bytearray()
            while True:
                line = self.rfile.readline(30).strip()
                if b";" in line: line = line.split(b";")[0]
                try: n = int(line, 16)
                except ValueError: return None
                if n == 0:
                    while True:
                        t = self.rfile.readline(80)
                        if t in (b"\r\n", b"\n", b""): break
                    break
                rem = n
                while rem > 0:
                    d = self.rfile.read(min(rem, 1<<20))
                    if not d: return None
                    buf += d; rem -= len(d)
                self.rfile.read(2)
                if len(buf) > 95*1024*1024: return None
            return bytes(buf)
        length = int(self.headers.get("Content-Length","0"))
        if length > 95*1024*1024: return None
        rem, buf = length, bytearray()
        while rem > 0:
            d = self.rfile.read(min(rem, 1<<20))
            if not d: break
            buf += d; rem -= len(d)
        return bytes(buf)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
        if u.path == "/":
            self._send(200, PAGE.replace("__PUBKEY__", base64.b64encode(SRV_PUB_RAW).decode()), "text/html; charset=utf-8")
        elif u.path == "/api/pubkey":
            self._send(200, base64.b64encode(SRV_PUB_RAW))
        elif u.path == "/api/list":
            box = q.get("box", [""])[0]
            out = {}
            for sub in ("inbox", "outbox"):
                d = box_dir(box, sub)
                if d is None: return self._send(400, "плохое имя ящика")
                out[sub] = [{"name": n, "size": f"{os.path.getsize(os.path.join(d,n))//1024} КБ"}
                            for n in sorted(os.listdir(d))]
            self._send(200, json.dumps(out, ensure_ascii=False).encode(), "application/json")
        elif u.path == "/api/get":
            d = box_dir(q.get("box",[""])[0], q.get("dir",["inbox"])[0])
            p = safe_join(d or "", q.get("f",[""])[0])
            if not p or not os.path.isfile(p): return self._send(404, "нет такого файла")
            self._send(200, open(p,"rb").read(), "application/octet-stream")
        else:
            self._send(404, "not found")

    def do_POST(self):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
        if u.path == "/api/send":
            raw = self._read_body()
            if raw is None: return self._send(413, "слишком большой (>95МБ) — используй шифр")
            box = q.get("box",[None])[0] or self._mp_field(raw,"box")
            fname = self._mp_filename(raw)
            d = box_dir(box, "inbox") if box else None
            if d is None or not fname: return self._send(400, "нужны ящик и файл")
            open(os.path.join(d, os.path.basename(fname)), "wb").write(self._mp_body(raw))
            self._send(200, f"OK: {fname} -> ящик {box}/inbox")
        elif u.path == "/dec":
            txt = (self._read_body() or b"").decode(errors="replace")
            try: data = self._decrypt_request(txt)
            except Exception as e:
                print("[dec-error]", e, flush=True)
                return self._send(400, f"расшифровка не удалась: {e}")
            self._send(200, data, "application/octet-stream")
        else:
            self._send(404, "not found")

    def do_PUT(self):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
        if u.path == "/enc":
            name = os.path.basename(q.get("name",["f.bin"])[0])
            try:
                total = int(q.get("total",["1"])[0]); idx = int(q.get("part",["0"])[0])
            except ValueError: return self._send(400, "bad params")
            body = self._read_body()
            if body is None: return self._send(413, "chunk too large")
            cdir = os.path.join(ENC, name + ".parts"); os.makedirs(cdir, exist_ok=True)
            open(os.path.join(cdir, f"part_{idx:03d}"), "wb").write(body)
            got = len([x for x in os.listdir(cdir) if x.startswith("part_")])
            if got >= total:
                dest = os.path.join(INCOMING, name)
                os.makedirs(INCOMING, exist_ok=True)
                with open(dest, "wb") as out:
                    for pn in sorted(os.listdir(cdir)):
                        out.write(open(os.path.join(cdir,pn),"rb").read())
                msg = f"DONE encrypted {name} ({os.path.getsize(dest)} bytes)"
            else:
                msg = f"saved part {idx+1}/{total} ({got} received)"
            print(msg, flush=True)
            self._send(200, msg)
        elif u.path.startswith("/api/keymsg"):
            box = q.get("box",[""])[0]; nm = os.path.basename(q.get("name",["key.txt"])[0])
            d = box_dir(box, "inbox")
            if d is None: return self._send(400, "плохой ящик")
            body = self._read_body()
            if body is None: return self._send(413, "too big")
            open(os.path.join(d, nm), "wb").write(body)
            self._send(200, "key letter saved")
        else:
            self._send(404, "not found")

    # --- multipart helpers ---
    @staticmethod
    def _mp_field(raw, field):
        m = re.search(rb'name="%s"\r\n\r\n([^\r\n]*)' % field.encode(), raw)
        return m.group(1).decode() if m else ""
    @staticmethod
    def _mp_filename(raw):
        m = re.search(rb'filename="([^"]+)"', raw)
        return m.group(1).decode() if m else ""
    @staticmethod
    def _mp_body(raw):
        m = re.search(rb'filename="[^"]*"\r\n\r\n', raw)
        if not m: return b""
        start = m.end(); end = raw.rfind(b"\r\n--")
        return raw[start:end if end > start else len(raw)]

    # --- серверная расшифровка ---
    def _decrypt_request(self, txt):
        kv = dict(re.findall(r"^(\w+)=(.+)$", txt, re.M))
        need = {"id","file","ephemeral_pub","wrapped_key","wrap_iv","parts"}
        if not need.issubset(kv): raise ValueError("письмо неполное")
        key = unwrap_file_key(kv["ephemeral_pub"], kv["wrapped_key"], kv["wrap_iv"])
        cid = kv["id"] + "_" + os.path.basename(kv["file"])
        path = os.path.join(INCOMING, cid)
        if not os.path.isfile(path): raise ValueError("зашифрованный файл не найден: " + cid)
        data = open(path, "rb").read()
        aesf = AESGCM(key)
        cs = 90*1024*1024; rec = cs + 12 + 16
        total = int(kv["parts"]); orig = int(kv.get("size","0"))
        out = bytearray()
        for i in range(total):
            ch = data[i*rec:(i+1)*rec]
            if len(ch) < 13: break
            out += aesf.decrypt(ch[:12], ch[12:], None)
        return bytes(out[:orig] if orig else out)

    def log_message(self, *a): pass

if __name__ == "__main__":
    print("mailbox listening on :8790", flush=True)
    ThreadingHTTPServer(("127.0.0.1", 8790), H).serve_forever()
