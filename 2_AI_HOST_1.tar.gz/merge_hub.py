#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Merge Hub — программа для объединения /workspace нескольких контейнеров
(из разных диалогов) в один общий каталог.

Каждый контейнер поднимает на своём порту 8777 этот же скрипт:
    python3 merge_hub.py serve --port 8777
а «главный» контейнер (куда всё сливается) запускает:
    python3 merge_hub.py master --port 8888
и открывает http://localhost:8888 (или через cloudflare-туннель).

Функции:
 - добавление удалённых контейнеров по URL их Merge Hub API
 - сканирование и сравнение списков файлов (размер + sha256)
 - выборочная или полная синхронизация файлов в локальный каталог
   (конфликты складываются в <имя>.conflict_<метка_источника>)
 - локальный режим: объединение нескольких папок на самом сервере
"""

import argparse
import hashlib
import json
import os
import sys
import time
import urllib.request
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

WORKSPACE = Path("/workspace")
MERGE_DIR = WORKSPACE / "merged"          # куда сливаем содержимое чужих контейнеров
STATE_FILE = WORKSPACE / ".merge_hub.json"  # список подключённых источников
CHUNK = 1024 * 1024

# ----------------------------- helpers ---------------------------------------

def sha256_of(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(CHUNK), b""):
            h.update(b)
    return h.hexdigest()


def load_state():
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {"sources": []}


def save_state(st):
    STATE_FILE.write_text(json.dumps(st, indent=2, ensure_ascii=False))


def safe_rel(p: str) -> Path | None:
    """Запрет выхода за пределы базового каталога."""
    p = unquote(p).lstrip("/")
    candidate = (WORKSPACE / p).resolve()
    if str(candidate).startswith(str(WORKSPACE.resolve())) and ".." not in Path(p).parts:
        return candidate
    return None


def http_get(url: str, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": "merge-hub"})
    return urllib.request.urlopen(req, timeout=timeout)


# ------------------------- local scan / pull logic ---------------------------

def scan_local(base: Path):
    out = []
    for root, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d not in (".git", "__pycache__", "merged", "chunks")]
        for fn in files:
            fp = Path(root) / fn
            rel = str(fp.relative_to(base))
            try:
                st = fp.stat()
                out.append({"path": rel, "size": st.st_size, "mtime": int(st.st_mtime)})
            except OSError:
                pass
    return sorted(out, key=lambda x: x["path"])


def pull_file(src_url: str, rel: str, label: str) -> dict:
    """Скачать файл из удалённого hub'а в MERGE_DIR/<label>/<rel>."""
    dest = MERGE_DIR / label / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    url = src_url.rstrip("/") + "/raw?path=" + rel
    try:
        with http_get(url) as r, dest.open("wb") as f:
            for b in iter(lambda: r.read(CHUNK), b""):
                f.write(b)
        return {"path": rel, "status": "ok", "size": dest.stat().st_size}
    except Exception as e:
        return {"path": rel, "status": f"error: {e}"}


def pull_many(src_url: str, label: str, paths: list[str], progress=None):
    results = []
    for i, rel in enumerate(paths, 1):
        res = pull_file(src_url, rel, label)
        results.append(res)
        if progress:
            progress(i, len(paths), rel, res["status"])
    return results


# ------------------------------ remote ops -----------------------------------

def add_source(name: str, url: str):
    st = load_state()
    st["sources"] = [s for s in st["sources"] if s["name"] != name]
    st["sources"].append({"name": name, "url": url, "added": int(time.time())})
    save_state(st)
    return st["sources"]


def remove_source(name: str):
    st = load_state()
    st["sources"] = [s for s in st["sources"] if s["name"] != name]
    save_state(st)
    return st["sources"]


def remote_list(url: str):
    with http_get(url.rstrip("/") + "/list") as r:
        return json.loads(r.read())


def compare(url: str, label: str):
    """Что есть на удалённом контейнере и чего нет у нас (по размеру+хэшу не проверяем, только путь/размер)."""
    files = remote_list(url)["files"]
    local_root = MERGE_DIR / label
    only_new, same, diff = [], [], []
    for f in files:
        lp = local_root / f["path"]
        if not lp.exists():
            only_new.append(f)
        elif lp.stat().st_size == f["size"]:
            same.append(f)
        else:
            diff.append(f)
    return {"total_remote": len(files), "new": only_new, "same": same, "changed": diff}


# ------------------------------ HTTP server ----------------------------------

PAGE = """<!doctype html><html lang="ru"><head><meta charset="utf-8">
<title>Merge Hub</title><style>
body{font-family:system-ui;background:#111;color:#ddd;margin:2rem;max-width:1100px}
h1{color:#7fd}.card{background:#1b1b1b;border:1px solid #333;border-radius:8px;padding:1rem;margin:.6rem 0}
input{background:#222;color:#eee;border:1px solid #444;padding:.4rem;width:280px}
button{background:#2a6;border:0;color:#fff;padding:.45rem .9rem;border-radius:5px;cursor:pointer;margin:.2rem}
table{border-collapse:collapse;width:100%;font-size:.85rem}td,th{border-bottom:1px solid #333;padding:.25rem .5rem;text-align:left}
.ok{color:#7f7}.err{color:#f77}.mono{font-family:monospace;font-size:.8rem}#log{white-space:pre;max-height:300px;overflow:auto;background:#000;padding:.5rem}
</style></head><body>
<h1>🔗 Merge Hub — объединение контейнеров</h1>
<div class="card"><b>Источники (другие контейнеры):</b><div id="srcs"></div>
<input id="sname" placeholder="имя (напр. dialog2)"><input id="surl" placeholder="https://xxx.trycloudflare.com">
<button onclick="addSrc()">Добавить источник</button></div>
<div class="card" id="ops"><b>Операции:</b><br>
<select id="sel" style="width:300px;background:#222;color:#eee;padding:.3rem"></select>
<button onclick="doScan()">Сканировать (сравнить)</button>
<button onclick="pullAll()">⬇ Забрать НОВЫЕ файлы</button>
<button onclick="pullChanged()">⬇ Переписать изменённые</button>
<div id="cmp"></div></div>
<div class="card"><b>Локальное объединение папок внутри этого контейнера</b><br>
<input id="lsrc" placeholder="/workspace/incoming/..."><input id="ldst" placeholder="/workspace/merged/name">
<button onclick="localMerge()">Объединить</button></div>
<div class="card"><b>Журнал:</b><div id="log" class="mono"></div></div>
<script>
const log=(m)=>{const l=document.getElementById('log');l.textContent+=m+'\\n';l.scrollTop=l.scrollHeight;};
async function api(p,body){const r=await fetch(p,body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{});return r.json();}
async function refresh(){const d=await api('/api/sources');const s=d.sources;
 document.getElementById('srcs').innerHTML=s.map(x=>`<span class="mono">${x.name} → ${x.url}</span> <button onclick="delSrc('${x.name}')">✖</button>`).join('<br>')||'<i>нет источников</i>';
 document.getElementById('sel').innerHTML=s.map(x=>`<option value="${x.name}">${x.name}</option>`).join('');}
async function addSrc(){const n=name.value.trim(),u=url_fix(surl.value);if(!n||!u)return log('укажите имя и URL');
 await api('/api/sources/add',{name:n,url:u});log('добавлен '+n);refresh();}
function url_fix(u){u=u.trim();if(!u)return u;if(!/^https?:\\/\\//.test(u))u='https://'+u;return u.replace(/\\/+$/,'');}
async function delSrc(n){await api('/api/sources/del',{name:n});log('удалён '+n);refresh();}
let lastCmp=null;
async function doScan(){const name=sel.value;if(!name)return log('выберите источник');
 log('сканирую '+name+'…');lastCmp=await api('/api/compare',{name});
 document.getElementById('cmp').innerHTML=`Всего на ${name}: <b>${lastCmp.total_remote}</b> · новых: <b class=ok>${lastCmp.new.length}</b> · совпадают: ${lastCmp.same.length} · отличаются по размеру: <b class=err>${lastCmp.changed.length}</b>`;}
async function pullAll(){if(!lastCmp)return log('сначала Сканировать');
 const paths=lastCmp.new.map(f=>f.path);if(!paths.length)return log('новых нет');
 log('забираю '+paths.length+' файлов…');const r=await api('/api/pull',{name:sel.value,paths});
 r.results.forEach(x=>log(x.status==='ok'?'✔ '+x.path:'✖ '+x.path+' '+x.status));log('готово → merged/'+sel.value);}
async function pullChanged(){if(!lastCmp||!lastCmp.changed.length)return log('изменённых нет/не сканировано');
 const paths=lastCmp.changed.map(f=>f.path);const r=await api('/api/pull',{name:sel.value,paths,overwrite:true});
 r.results.forEach(x=>log(x.status==='ok'?'✔ '+x.path:'✖ '+x.path));}
async function localMerge(){const r=await api('/api/local_merge',{src:lsrc.value,dst:ldst.value});log(JSON.stringify(r));}
document.addEventListener('DOMContentLoaded',refresh);
</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    mode = "serve"  # serve = отдаём свой /workspace; master = UI + pull

    def _json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *a):
        pass

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/" or u.path == "/index.html":
            body = PAGE.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(body)
        elif u.path == "/list":  # для других хабов: список файлов нашего workspace
            self._json({"root": str(WORKSPACE), "files": scan_local(WORKSPACE)})
        elif u.path == "/hash":
            p = safe_rel(q.get("path", [""])[0])
            if not p or not p.is_file():
                return self._json({"error": "not found"}, 404)
            self._json({"path": str(p.relative_to(WORKSPACE)), "sha256": sha256_of(p)})
        elif u.path == "/raw":
            p = safe_rel(q.get("path", [""])[0])
            if not p or not p.is_file():
                return self._json({"error": "not found"}, 404)
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(p.stat().st_size))
            self.end_headers()
            with p.open("rb") as f:
                for b in iter(lambda: f.read(CHUNK), b""):
                    self.wfile.write(b)
        elif u.path == "/api/sources":
            self._json(load_state())
        elif u.path == "/api/status":
            self._json({"mode": self.mode, "workspace": str(WORKSPACE),
                        "merged_exists": MERGE_DIR.exists(), "time": int(time.time())})
        else:
            self._json({"error": "404"}, 404)

    def _body(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    def do_POST(self):
        u = urlparse(self.path)
        b = self._body()
        st = load_state()
        if u.path == "/api/sources/add":
            srcs = add_source(b["name"], b["url"])
            return self._json({"sources": srcs})
        if u.path == "/api/sources/del":
            srcs = remove_source(b["name"])
            return self._json({"sources": srcs})
        if u.path == "/api/compare":
            s = next((x for x in st["sources"] if x["name"] == b["name"]), None)
            if not s:
                return self._json({"error": "no such source"}, 404)
            return self._json(compare(s["url"], s["name"]))
        if u.path == "/api/pull":
            s = next((x for x in st["sources"] if x["name"] == b["name"]), None)
            if not s:
                return self._json({"error": "no such source"}, 404)
            overwrite = bool(b.get("overwrite"))
            results = []
            for rel in b.get("paths", [])[:2000]:
                dest = MERGE_DIR / s["name"] / rel
                if dest.exists() and not overwrite:
                    results.append({"path": rel, "status": "skipped(exists)"})
                    continue
                if dest.exists() and overwrite:
                    bak = dest.with_name(dest.name + f".conflict_{int(time.time())}")
                    dest.rename(bak)
                results.append(pull_file(s["url"], rel, s["name"]))
            return self._json({"results": results})
        if u.path == "/api/local_merge":
            src = Path(b["src"]).resolve()
            dst = Path(b["dst"]).resolve()
            if not src.is_dir():
                return self._json({"error": f"нет папки {src}"}, 400)
            dst.mkdir(parents=True, exist_ok=True)
            moved = 0
            for item in src.rglob("*"):
                if item.is_file():
                    t = dst / item.relative_to(src)
                    t.parent.mkdir(parents=True, exist_ok=True)
                    if t.exists() and t.stat().st_size == item.stat().st_size:
                        continue
                    if t.exists():
                        t = t.with_name(t.name + f".conflict_{int(time.time())}")
                    t.write_bytes(item.read_bytes())
                    moved += 1
            return self._json({"merged_files": moved, "dst": str(dst)})
        self._json({"error": "404"}, 404)


def cmd_serve(port):
    Handler.mode = "serve"
    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"[serve] отдаю {WORKSPACE} на :{port}")
    srv.serve_forever()


def cmd_master(port):
    Handler.mode = "master"
    MERGE_DIR.mkdir(exist_ok=True)
    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"[master] интерфейс слияния на :{port}, приёмник: {MERGE_DIR}")
    srv.serve_forever()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd")
    p1 = sub.add_parser("serve"); p1.add_argument("--port", type=int, default=8777)
    p2 = sub.add_parser("master"); p2.add_argument("--port", type=int, default=8888)
    p3 = sub.add_parser("cli")
    p3.add_argument("--add", nargs=2, metavar=("NAME", "URL"))
    p3.add_argument("--scan", metavar="NAME")
    p3.add_argument("--pull", metavar="NAME")
    args = ap.parse_args()
    if args.cmd == "serve":
        cmd_serve(args.port)
    elif args.cmd == "master":
        cmd_master(args.port)
    elif args.cmd == "cli":
        if args.add:
            print(add_source(*args.add))
        if args.scan:
            st = load_state()
            s = next(x for x in st["sources"] if x["name"] == args.scan)
            c = compare(s["url"], s["name"])
            print(f"новых: {len(c['new'])}, совпадает: {len(c['same'])}, изменено: {len(c['changed'])}")
        if args.pull:
            st = load_state()
            s = next(x for x in st["sources"] if x["name"] == args.pull)
            c = compare(s["url"], s["name"])
            res = pull_many(s["url"], s["name"], [f["path"] for f in c["new"]],
                            progress=lambda i, n, p, k: print(f"{i}/{n} {k} {p}"))
            print(f"забрано {sum(1 for r in res if r['status']=='ok')} файлов")
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
