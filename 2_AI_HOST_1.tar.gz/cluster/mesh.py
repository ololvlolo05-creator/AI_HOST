#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mesh Registry — самоисцеляющаяся пуповина между контейнерами.

Каждый контейнер запускает ОДИН сервис (mesh-агент) на :8585, который:
  * является и воркером MegaFS (/stat,/ls,/get,/put,/mkdir,/del по /workspace),
  * хранит память peers.json (имя -> url + last_seen) — ЗАПОМНИЛ адреса других,
  * принимает POST /hello {name,url} от соседа -> записывает его адрес,
    затем сам стучится соседу на /hello со СВОИМ свежим адресом (обратная
    прививка = маршрутизация обновляется в обе стороны сразу),
  * GET /peers -> текущая таблица,
  * GET /health -> кто из соседей жив прямо сейчас (пингует всех).

Роль (worker|gateway) задаётся env MESH_ROLE; gateway дополнительно отдаёт
единое дерево файлов через логику megafs.GatewayHandler (см. run_gateway).

Зародыш сети (bootstrap): любой известный URL соседа -> POST /hello.
Если контейнер умер и ожил с НОВЫМ адресом — первый же hello или scan
(гейтвей пингует список старых URL; worker отвечает с новым адресом только
после перезапуска, поэтому переподключение делает человек/бот: см. README).
"""
import json, os, sys, time, threading, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "gateway"))
WORKER_ROOT = "/workspace"
PEERS_PATH = os.path.join(HERE, "peers.json")
MY_NAME = os.environ.get("MESH_NAME", "w1")
LOCK = threading.Lock()


def load_peers():
    try:
        with open(PEERS_PATH) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_peers(d):
    tmp = PEERS_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(d, f, indent=2)
    os.replace(tmp, PEERS_PATH)


def http_json(url, payload=None, timeout=8):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())


def say_hello(peer_url):
    """Сообщить соседу свой адрес и получить его таблицу."""
    try:
        resp = http_json(peer_url.rstrip("/") + "/hello",
                         {"name": MY_NAME, "url": MY_URL})
        with LOCK:
            peers = load_peers()
            for n, info in (resp.get("peers") or {}).items():
                if n != MY_NAME:
                    peers[n] = info
            peers[resp.get("you", "?")] = {"url": peer_url,
                                           "last_seen": time.time()}
            save_peers(peers)
        return resp
    except Exception as e:
        return {"err": str(e)}


MY_URL = os.environ.get("MESH_URL", "")  # подставляется при старте


class MeshHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _j(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b)

    # ---------- worker API (совместимо с megafs) ----------
    def do_GET(self):
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/peers":
            return self._j(200, {"me": MY_NAME, "my_url": MY_URL,
                                 "role": os.environ.get("MESH_ROLE", "worker"),
                                 "peers": load_peers()})
        if u.path == "/health":
            out = {}
            with LOCK:
                peers = load_peers()
            for n, info in peers.items():
                try:
                    st = http_json(info["url"].rstrip("/") + "/stat?p=", timeout=4)
                    out[n] = {"alive": True, "used": st.get("used")}
                except Exception:
                    out[n] = {"alive": False}
            return self._j(200, out)
        # остальное — воркер-файловый API из megafs
        from megafs import WorkerHandler
        self.path = u.path + ("?" + u.query if u.query else "")
        WorkerHandler.do_GET(self)

    def do_POST(self):
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        if u.path == "/hello":
            ln = int(self.headers.get("Content-Length", 0))
            try:
                d = json.loads(self.rfile.read(ln))
            except Exception:
                return self._j(400, {"err": "bad json"})
            name, url = d.get("name"), d.get("url")
            if not name or not url:
                return self._j(400, {"err": "need name,url"})
            with LOCK:
                peers = load_peers()
                peers[name] = {"url": url, "last_seen": time.time()}
                save_peers(peers)
            # обратная прививка: пусть сосед тоже запомнил нас
            threading.Thread(target=say_hello, args=(url,), daemon=True).start()
            return self._j(200, {"ok": True, "you": MY_NAME,
                                 "peers": load_peers()})
        from megafs import WorkerHandler
        self.path = u.path + ("?" + u.query if u.query else "")
        WorkerHandler.do_POST(self)


def main():
    global MY_URL
    import shutil
    import megafs
    megafs.WORKER_CAP = shutil.disk_usage(WORKER_ROOT).total
    port = int(os.environ.get("MESH_PORT", "8585"))
    # если MESH_URL не задан — берём из файла (пишет start_all.sh после взлёта туннеля)
    if not MY_URL and os.path.exists("/tmp/mesh_url.txt"):
        MY_URL = open("/tmp/mesh_url.txt").read().strip()
    boot = os.environ.get("MESH_BOOTSTRAP", "")  # url соседа для первого hello
    srv = ThreadingHTTPServer(("0.0.0.0", port), MeshHandler)
    print(f"mesh agent '{MY_NAME}' on :{port}, url={MY_URL}", flush=True)
    if boot:
        threading.Thread(target=say_hello, args=(boot,), daemon=True).start()
    srv.serve_forever()


if __name__ == "__main__":
    main()
