#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MegaDisk Gateway — ЕДИНЫЙ диск поверх всех контейнеров сети.

Отличия от старого megafs gateway:
  * список воркеров НЕ статический — читается из cluster/peers.json (память mesh)
    и обновляется на лету каждые N секунд;
  * сам гейтвей тоже является узлом mesh: соседи могут стучать ему /hello,
    его адрес запоминается у них, чужие — у него;
  * локальный /workspace — это worker "self", т.е. единый диск включает и
    эту машину (Σ ёмкостей = эта + все живые соседи);
  * есть человекочитаемая панель GET / — статус сети и объём мего-диска.

Единое дерево файлов:
  GET  /tree            — json-дерево (файл -> какой воркер его держит)
  GET  /fs/<путь>       — скачать файл (ищется по index, потом перебором)
  POST /upload?path=..  — залить файл на самый свободный живой воркер
  POST /mkdir?path=..   — создать папку на всех воркерах
  GET  /health          — кто жив, Σ used / Σ cap
  POST /hello {name,url}— присоединить новый контейнер к сети (mesh)
  GET  /peers           — таблица соседей

Запуск: python3 megadisk.py --port 8443 [--bootstrap URL_СОСЕДА]
env: MESH_NAME=gateway, MESH_URL=публичный url гейтвея
"""
import json, os, sys, time, threading, argparse, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "gateway"))
import megafs
from megafs import GatewayHandler, peer_usage, load_index, save_index

PEERS_PATH = os.path.join(HERE, "peers.json")
MY_NAME = os.environ.get("MESH_NAME", "gateway")
MY_URL = os.environ.get("MESH_URL", "")
SELF_ROOT = "/workspace"          # локальный воркер = этот контейнер
LOCK = threading.Lock()


def load_peers_file():
    try:
        with open(PEERS_PATH) as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def refresh_peers():
    """Раз в минуту переносим память mesh (peers.json) в живой PEERS."""
    while True:
        try:
            with LOCK:
                for n, info in load_peers_file().items():
                    if n == MY_NAME:
                        continue
                    url = info.get("url") if isinstance(info, dict) else info
                    if url and not url.startswith("http://127."):
                        megafs.PEERS[n] = {"url": url.rstrip("/")}
            # ping: выкидываем мёртвых, но не чаще раза в цикл
            for n in list(megafs.PEERS):
                if n == MY_NAME:
                    continue
                try:
                    with urllib.request.urlopen(megafs.PEERS[n]["url"] + "/stat?p=", timeout=5):
                        pass
                except Exception:
                    pass  # оставляем в списке — может ожить (самоисцеление)
        except Exception:
            pass
        time.sleep(60)


class DiskHandler(GatewayHandler):
    def do_POST(self):
        u = urlparse(self.path)
        if u.path == "/hello":
            ln = int(self.headers.get("Content-Length", 0))
            try:
                d = json.loads(self.rfile.read(ln))
            except Exception:
                return self._j(400, {"err": "bad json"})
            name, url = d.get("name"), d.get("url")
            if not name or not url:
                return self._j(400, {"err": "need name,url"})
            with LOCK:
                p = load_peers_file()
                p[name] = {"url": url, "last_seen": time.time()}
                tmp = PEERS_PATH + ".tmp"
                with open(tmp, "w") as f:
                    json.dump(p, f, indent=2)
                os.replace(tmp, PEERS_PATH)
                megafs.PEERS[name] = {"url": url.rstrip("/")}
            # обратная прививка своего адреса
            try:
                req = urllib.request.Request(url.rstrip("/") + "/hello",
                        data=json.dumps({"name": MY_NAME, "url": MY_URL}).encode(),
                        headers={"Content-Type": "application/json"}, method="POST")
                urllib.request.urlopen(req, timeout=8).read()
            except Exception:
                pass
            return self._j(200, {"ok": True, "you": MY_NAME,
                                 "peers": {k: v["url"] for k, v in megafs.PEERS.items()}})
        return GatewayHandler.do_POST(self)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/peers":
            return self._j(200, {"me": MY_NAME, "my_url": MY_URL,
                                 "peers": {k: v["url"] for k, v in megafs.PEERS.items()}})
        if u.path == "/":
            h = None
            try:
                import io
                buf = io.StringIO()
                self.path = "/health?"
                # тихий вызов health
                orig = self.wfile
                self.wfile = buf
                GatewayHandler.do_GET.__wrapped__ if False else None
                # проще: собрать вручную
                alive = {n: peer_usage(n) for n in megafs.PEERS}
                total_cap = sum(c for (_, c) in alive.values() if c)
                total_used = sum(x for (x, _) in alive.values() if x is not None)
                rows = "".join(
                    f"<tr><td>{n}</td><td>{megafs.PEERS[n]['url']}</td>"
                    f"<td>{'ЖИВ' if a[0] is not None else 'мёртв (жду пуповину)'}</td>"
                    f"<td>{(a[0] or 0)/2**30:.1f} / {(a[1] or 0)/2**30:.1f} ГБ</td></tr>"
                    for n, a in alive.items())
                html = (f"<html><body style='font-family:monospace'>"
                        f"<h2>MegaDisk — единый диск</h2>"
                        f"<p>Ёмкость сети: <b>{total_cap/2**30:.1f} ГБ</b>, занято {total_used/2**30:.1f} ГБ</p>"
                        f"<table border=1 cellpadding=6><tr><th>узел</th><th>url</th><th>статус</th><th>занято/ёмкость</th></tr>{rows}</table>"
                        f"<p>API: /tree /fs/&lt;путь&gt; POST /upload?path= /health /peers POST /hello</p>"
                        f"</body></html>")
                b = html.encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(b)
                return
            except Exception:
                pass
        return GatewayHandler.do_GET(self)


def _start_self_worker():
    import shutil
    megafs.WORKER_CAP = shutil.disk_usage("/workspace").total
    from megafs import WorkerHandler
    ThreadingHTTPServer(("127.0.0.1", 8586), WorkerHandler).serve_forever()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8443)
    ap.add_argument("--bootstrap", default=os.environ.get("MESH_BOOTSTRAP", ""))
    args = ap.parse_args()

    global MY_URL
    if not MY_URL and os.path.exists("/tmp/mesh_url.txt"):
        MY_URL = open("/tmp/mesh_url.txt").read().strip()

    # сам себе воркер: локальный /workspace участвует в едином диске
    megafs.WORKER_ROOT = SELF_ROOT
    threading.Thread(target=_start_self_worker, daemon=True).start()
    time.sleep(0.5)
    megafs.PEERS[MY_NAME] = {"url": "http://127.0.0.1:8586"}

    # peers.json -> PEERS
    for n, info in load_peers_file().items():
        url = info.get("url") if isinstance(info, dict) else info
        if url and n != MY_NAME and not url.startswith("http://127."):
            megafs.PEERS[n] = {"url": url.rstrip("/")}

    threading.Thread(target=refresh_peers, daemon=True).start()

    if args.bootstrap:
        try:
            req = urllib.request.Request(args.bootstrap.rstrip("/") + "/hello",
                    data=json.dumps({"name": MY_NAME, "url": MY_URL}).encode(),
                    headers={"Content-Type": "application/json"}, method="POST")
            resp = json.loads(urllib.request.urlopen(req, timeout=10).read())
            for n, info in (resp.get("peers") or {}).items():
                url2 = info.get("url") if isinstance(info, dict) else info
                if url2 and n != MY_NAME:
                    megafs.PEERS[n] = {"url": url2.rstrip("/")}
            print("bootstrap ok:", list(megafs.PEERS), flush=True)
        except Exception as e:
            print("bootstrap fail:", e, flush=True)

    srv = ThreadingHTTPServer(("0.0.0.0", args.port), DiskHandler)
    print(f"megadisk gateway on :{args.port}, nodes={list(megafs.PEERS)}", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
