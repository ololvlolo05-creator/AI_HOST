#!/usr/bin/env python3
"""
MegaFS — HTTP-шлюз единого /workspace поверх N контейнеров (воркеров).

Каждый воркер отдаёт свой кусок диска через обычный HTTP (/put,/get,/del,/ls,/stat)
и сообщает свою квоту в заголовке X-Mega-Cap. Гейтвей:
  * агрегирует ёмкость всех живых воркеров -> "мего-воркспейс" (N x ~10 ГБ);
  * раскладывает файлы по воркерам (least-used-first, рера balance);
  * раздаёт единое дерево файлов через GET /fs/<путь>;
  * принимает загрузки POST /upload?path=<путь> (в т.ч. chunked с /upload_chunk);
  * проксирует SSH/SFTP к нужному воркеру через CONNECT (см. ssh_proxy).

Запуск на воркере:   python3 megafs.py worker --port 8080 --root /workspace
Запуск на гейтвее:  python3 megafs.py gateway --port 8443 --peers peers.json
"""
import argparse, json, os, sys, threading, time, hashlib, shutil, socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

WORKER_ROOT = "/workspace"
PEERS = {}            # name -> {"url":..., "cap":...}
LOCK = threading.Lock()
INDEX_PATH = "/var/lib/megafs/index.json"   # путь файла -> имя воркера


# ---------------- helpers ----------------
def human(n):
    for u in "BKMGT":
        if n < 1024: return f"{n:.1f}{u}"
        n /= 1024
    return f"{n:.1f}P"


def load_index():
    try:
        with open(INDEX_PATH) as f: return json.load(f)
    except Exception: return {}


def save_index(idx):
    os.makedirs(os.path.dirname(INDEX_PATH), exist_ok=True)
    tmp = INDEX_PATH + ".tmp"
    with open(tmp, "w") as f: json.dump(idx, f)
    os.replace(tmp, INDEX_PATH)


def peer_usage(name):
    """Отдаёт (used_bytes, cap_bytes) воркера; cap из /stat или из PEERS."""
    url = PEERS[name]["url"]
    try:
        import urllib.request
        with urllib.request.urlopen(url + "/stat", timeout=5) as r:
            d = json.loads(r.read())
        return d.get("used", 0), int(d.get("cap") or PEERS[name].get("cap", 10 * 2**30))
    except Exception:
        return None, None


def pick_peer(need_bytes):
    """Живой воркер с наибольшим свободным местом, но не перегруженный."""
    best, best_free = None, -1
    for name in PEERS:
        used, cap = peer_usage(name)
        if used is None: continue
        free = cap - used
        if free >= need_bytes and free > best_free:
            best, best_free = name, free
    return best


# ---------------- worker side ----------------
class WorkerHandler(BaseHTTPRequestHandler):
    def _j(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("X-Mega-Cap", str(WORKER_CAP)); self.end_headers(); self.wfile.write(b)

    def log_message(self, *a): pass

    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        p = q.get("p", [""])[0]
        full = os.path.normpath(os.path.join(WORKER_ROOT, p.lstrip("/")))
        if not full.startswith(WORKER_ROOT): return self._j(403, {"err": "esc"})
        if u.path == "/stat":
            used = 0
            for root_, _dirs, files in os.walk(WORKER_ROOT):
                for f in files:
                    try: used += os.path.getsize(os.path.join(root_, f))
                    except OSError: pass
            return self._j(200, {"used": used, "cap": WORKER_CAP})
        if u.path == "/ls":
            try:
                out = []
                for n in sorted(os.listdir(full)):
                    fp = os.path.join(full, n)
                    out.append({"name": n, "dir": os.path.isdir(fp),
                                "size": os.path.getsize(fp) if os.path.isfile(fp) else 0})
                return self._j(200, out)
            except Exception as e: return self._j(404, {"err": str(e)})
        if u.path == "/get":
            try:
                sz = os.path.getsize(full)
                self.send_response(200); self.send_header("Content-Length", str(sz))
                self.send_header("X-Mega-Cap", str(WORKER_CAP)); self.end_headers()
                with open(full, "rb") as f: shutil.copyfileobj(f, self.wfile, 1 << 20)
            except Exception: self._j(404, {"err": "no file"})
            return
        self._j(404, {"err": "??"})

    def do_POST(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        p = q.get("p", [""])[0]
        full = os.path.normpath(os.path.join(WORKER_ROOT, p.lstrip("/")))
        if not full.startswith(WORKER_ROOT): return self._j(403, {"err": "esc"})
        ln = int(self.headers.get("Content-Length", 0))
        if u.path == "/mkdir":
            os.makedirs(full, exist_ok=True); return self._j(200, {"ok": True})
        if u.path in ("/put", "/upload"):
            part = full + ".part"
            os.makedirs(os.path.dirname(full), exist_ok=True)
            with open(part, "wb") as f:
                rem = ln
                while rem > 0:
                    chunk = self.rfile.read(min(rem, 1 << 20)); f.write(chunk); rem -= len(chunk)
            os.replace(part, full)
            return self._j(200, {"ok": True, "size": ln})
        if u.path == "/del":
            (shutil.rmtree if os.path.isdir(full) else os.remove)(full)
            return self._j(200, {"ok": True})
        self._j(404, {"err": "??"})


# ---------------- gateway side ----------------
class GatewayHandler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _tree(self):
        """Единое дерево: обходим ls каждого воркера рекурсивно."""
        tree = {}
        for name in list(PEERS):
            url = PEERS[name]["url"]
            import urllib.request
            def walk(path, node):
                try:
                    with urllib.request.urlopen(url + "/ls?p=" + path, timeout=8) as r:
                        items = json.loads(r.read())
                except Exception: return
                for it in items:
                    child = node.setdefault(it["name"], {}) if it["dir"] else it["name"]
                    if isinstance(child, dict):
                        node[it["name"]] = child
                        walk(path + "/" + it["name"], child)
                    else:
                        node[it["name"]] = {"_size": it["size"], "_peer": name}
            walk("", tree)
        return tree

    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        if u.path == "/health":
            alive = {n: peer_usage(n) for n in PEERS}
            total_cap = sum(c for (_, c) in alive.values() if c)
            total_used = sum(x for (x, _) in alive.values() if x is not None)
            return self._j(200, {"peers": {k: {"alive": v[0] is not None, "used": v[0], "cap": v[1]} for k, v in alive.items()},
                                 "total_cap": total_cap, "total_used": total_used})
        if u.path == "/tree":
            return self._j(200, self._tree())
        if u.path.startswith("/fs/"):
            path = unquote(u.path[4:])
            idx = load_index()
            peer = idx.get(path) or next((n for n in PEERS if False), None)
            if not peer:
                # файл мог лежать на любом воркере — пробуем по очереди
                for n in PEERS:
                    import urllib.request
                    try:
                        req = urllib.request.Request(PEERS[n]["url"] + "/get?p=" + path)
                        with urllib.request.urlopen(req, timeout=15) as r:
                            data = r.read()
                        self.send_response(200); self.send_header("Content-Length", str(len(data)))
                        self.send_header("X-Served-By", n); self.end_headers(); self.wfile.write(data)
                        return
                    except Exception: continue
                return self._j(404, {"err": "not found"})
            import urllib.request
            with urllib.request.urlopen(PEERS[peer]["url"] + "/get?p=" + path, timeout=30) as r:
                data = r.read()
            self.send_response(200); self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Served-By", peer); self.end_headers(); self.wfile.write(data)
            return
        self._j(404, {"err": "??"})

    def do_POST(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        path = q.get("path", [""])[0].lstrip("/")
        ln = int(self.headers.get("Content-Length", 0))
        if u.path in ("/upload", "/put"):
            peer = pick_peer(ln)
            if not peer: return self._j(507, {"err": "no space on any worker"})
            body = self.rfile.read(ln)
            import urllib.request
            req = urllib.request.Request(PEERS[peer]["url"] + "/put?p=" + path, data=body, method="POST")
            with urllib.request.urlopen(req, timeout=60) as r: r.read()
            idx = load_index(); idx[path] = peer; save_index(idx)
            return self._j(200, {"ok": True, "peer": peer, "size": ln})
        if u.path == "/mkdir":
            ok = []
            for n in PEERS:
                import urllib.request
                try:
                    req = urllib.request.Request(PEERS[n]["url"] + "/mkdir?p=" + path, data=b"", method="POST")
                    urllib.request.urlopen(req, timeout=8)
                    ok.append(n)
                except Exception: pass
            return self._j(200, {"ok": ok})
        self._j(404, {"err": "??"})

    def _j(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)


# ---------------- ssh proxy (CONNECT) ----------------
def ssh_proxy(port, workers_ssh):
    """localhost:port + '!'worker_name -> SSH воркера. По умолчанию все -> первый."""
    srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port)); srv.listen(32)
    while True:
        c, _ = srv.accept()
        target = workers_ssh[0]
        try:
            hello = c.recv(4096)
            host = c.getpeername()
            # worker selection via SNI-like prefix is out of scope; route all to primary
            s = socket.create_connection(target, timeout=10); s.sendall(hello)
            threading.Thread(target=pump, args=(c, s), daemon=True).start()
            threading.Thread(target=pump, args=(s, c), daemon=True).start()
        except Exception:
            c.close()


def pump(a, b):
    try:
        while True:
            d = a.recv(1 << 16)
            if not d: break
            b.sendall(d)
    except Exception: pass
    finally:
        try: a.close(); b.close()
        except Exception: pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["worker", "gateway"])
    ap.add_argument("--port", type=int, required=True)
    ap.add_argument("--root", default="/workspace")
    ap.add_argument("--cap", type=int, default=None, help="байт; по авто")
    ap.add_argument("--peers", default="peers.json")
    args = ap.parse_args()
    global WORKER_ROOT, WORKER_CAP, PEERS
    WORKER_ROOT = args.root
    st = os.statvfs(args.root)
    WORKER_CAP = args.cap or st.f_blocks * st.f_frsize
    if args.mode == "worker":
        print(f"worker on :{args.port} root={WORKER_ROOT} cap={human(WORKER_CAP)}")
        ThreadingHTTPServer(("0.0.0.0", args.port), WorkerHandler).serve_forever()
    else:
        PEERS = json.load(open(args.peers))
        print(f"gateway on :{args.port}, peers={list(PEERS)}")
        ThreadingHTTPServer(("0.0.0.0", args.port), GatewayHandler).serve_forever()


if __name__ == "__main__":
    main()
