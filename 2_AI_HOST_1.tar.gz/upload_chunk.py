#!/usr/bin/env python3
"""Chunked upload receiver: bypasses Cloudflare Quick Tunnel 100MB POST limit.

Usage (Windows cmd):
  curl -T "C:\path\archive.rar" https://<tunnel-host>/upload?name=archive.rar&total=4

Server saves file to /workspace/incoming/<name>, assembling chunks in order.
"""
import os, cgi, urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer

INCOMING = "/workspace/incoming"
CHUNKS = "/workspace/chunks"
os.makedirs(INCOMING, exist_ok=True)
os.makedirs(CHUNKS, exist_ok=True)

class H(BaseHTTPRequestHandler):
    def _cors(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "PUT, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")

    def do_OPTIONS(self):
        self.send_response(200); self._cors(); self.end_headers()

    def do_PUT(self):
        q = urllib.parse.urlparse(self.path).query
        p = urllib.parse.parse_qs(q)
        name = os.path.basename(p.get("name", ["file.bin"])[0])
        total = int(p.get("total", ["1"])[0])
        idx = int(p.get("part", [str(total - 1)])[0])  # last part by default
        length = int(self.headers.get("Content-Length", "0"))
        if length > 95 * 1024 * 1024:
            self.send_response(413); self._cors(); self.end_headers()
            self.wfile.write(b"chunk too large (>95MB)")
            return
        cdir = os.path.join(CHUNKS, name + ".parts")
        os.makedirs(cdir, exist_ok=True)
        remaining = length
        with open(os.path.join(cdir, f"part_{idx:03d}"), "wb") as f:
            while remaining > 0:
                data = self.rfile.read(min(remaining, 1 << 20))
                if not data: break
                f.write(data); remaining -= len(data)
        parts = sorted(os.listdir(cdir))
        msg = f"saved chunk {idx+1}/{total} ({len(parts)} received)"
        if len(parts) >= total:
            dest = os.path.join(INCOMING, name)
            with open(dest, "wb") as out:
                for pn in parts:
                    with open(os.path.join(cdir, pn), "rb") as inp:
                        out.write(inp.read())
            size = os.path.getsize(dest)
            for pn in parts: os.remove(os.path.join(cdir, pn))
            os.rmdir(cdir)
            msg = f"DONE: {name} assembled, {size} bytes"
        self.send_response(200); self._cors()
        self.send_header("Content-Type", "text/plain"); self.end_headers()
        self.wfile.write((msg + "\n").encode())
        print(msg, flush=True)

    def do_GET(self):
        body = PAGE.encode()
        self.send_response(200)
        self._cors()
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

PAGE = """<!doctype html><html lang="ru"><head><meta charset="utf-8">
<title>Загрузка архива (по частям)</title>
<style>body{font-family:Segoe UI,sans-serif;max-width:640px;margin:40px auto;padding:0 16px}
input,button{font-size:16px;padding:8px}button{cursor:pointer}
#bar{width:100%;height:22px;background:#eee;border-radius:6px;overflow:hidden;margin:12px 0}
#fill{height:100%;width:0;background:#2b7;color:#fff;text-align:center;font-size:13px;line-height:22px;transition:width .2s}
#log{white-space:pre-wrap;background:#111;color:#0f0;padding:10px;border-radius:6px;font-family:monospace;font-size:13px;min-height:60px}</style></head>
<body><h2>Загрузка больших файлов через Cloudflare</h2>
<p>Файл разбивается на части по 90 МБ прямо в браузере и отправляется последовательно — обход лимита 100 МБ.</p>
<input type="file" id="f"><br><br>
<button id="go" onclick="up()">Отправить</button> <span id="st"></span>
<div id="bar"><div id="fill"></div></div><div id="log"></div>
<script>
const CS=90*1024*1024, log=document.getElementById('log'), fill=document.getElementById('fill'), st=document.getElementById('st');
function L(m){log.textContent+=m+"\\n";log.scrollTop=1e9;}
async function up(){
 const f=document.getElementById('f').files[0]; if(!f){alert("Выбери файл");return;}
 const name=f.name.replace(/[^A-Za-z0-9._-]/g,'_');
 const total=Math.ceil(f.size/CS); L(`Файл: ${f.name} (${(f.size/1048576).toFixed(1)} MB), частей: ${total}`);
 document.getElementById('go').disabled=true;
 for(let i=0;i<total;i++){
   const blob=f.slice(i*CS,(i+1)*CS);
   let ok=false;
   for(let r=0;r<3&&!ok;r++){
     try{
       const res=await fetch(`/upload?name=${encodeURIComponent(name)}&total=${total}&part=${i}`,{method:'PUT',body:blob});
       const t=await res.text();
       if(res.ok){ok=true;L(`часть ${i+1}/${total}: ${t.trim()}`);}else L(`часть ${i+1}: ошибка ${res.status}, повтор ${r+1}`);
     }catch(e){L(`часть ${i+1}: сбой сети (${e.message}), повтор ${r+1}`);}
   }
   if(!ok){st.textContent="ОСТАНОВЛЕНО";document.getElementById('go').disabled=false;return;}
   fill.style.width=Math.round((i+1)/total*100)+"%";fill.textContent=Math.round((i+1)/total*100)+"%";
 }
 st.textContent="Готово! Файл собран в /workspace/incoming/"+name;
 document.getElementById('go').disabled=false;}
</script></body></html>"""

if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 8788), H).serve_forever()
