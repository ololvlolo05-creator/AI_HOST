#!/bin/bash
# Диагностика доступности TinkCloud WebDAV
T="${TINK_TOKEN:-tck_a2vDLiW9aQlr-9wGc_55CEZOPvX5d8slEAeHZI-zdpc}"
U="ololl08@tinkmail.me"
for path in "/dav/" "/dav/Mega-Workspace/"; do
  code=$(curl -sk -o /dev/null -m 15 -w "%{http_code}" -X PROPFIND "https://tinkcloud.com${path}" -H "Depth: 0" -u "$U:$T")
  echo "PROPFIND ${path} -> $code"
done
